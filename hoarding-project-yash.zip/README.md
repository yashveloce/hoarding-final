Change this file to give base info for all the developers
